mruby-class-new-fiber-safe
====

[![Build Status](https://travis-ci.org/kazuho/mruby-class-new-fiber-safe.svg?branch=master)](https://travis-ci.org/kazuho/mruby-class-new-fiber-safe)

Class#new that allows the use of fiber in constructor.

See also: https://github.com/mruby/mruby/issues/3879

Acknowledgements
----

Advices from [@miura1729](https://github.com/miura1729) and [@take-cheeze](https://github.com/take-cheeze) helped a lot in writing this mrbgem.

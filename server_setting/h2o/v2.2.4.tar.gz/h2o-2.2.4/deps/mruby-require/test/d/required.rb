# global variables
$gvar0 = 1
$gvar1 = 1

# toplevel local variables
lvar0 = 1
lvar1 = 1

# define a procedure
def proc0
  :proc0
end

# define a new method of an existing class.
class MrubyRequireClass
  def foo
    :foo
  end
end
